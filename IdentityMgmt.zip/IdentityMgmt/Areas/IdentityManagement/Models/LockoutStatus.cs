namespace $safeprojectname$.Areas.IdentityManagement.Models
{
    public enum LockoutStatus
    {
        Locked = 1,
        Unlocked = 2
    }
}
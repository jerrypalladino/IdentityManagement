namespace $safeprojectname$.Areas.IdentityManagement.Models
{
    public class ActionError
    {
        public string Reason { get; set; }
        public string Details { get; set; }
    }
}